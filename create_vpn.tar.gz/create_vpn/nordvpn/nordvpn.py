#!/usr/bin/python
from jinja2 import Environment, FileSystemLoader
import yaml
import subprocess
import sys
 
DOCKER_FILE_PATH = './compose/docker-compose.yml'
#CMD = str(sys.argv[1])
 
def genarate_config():
   config_data = yaml.safe_load(open('./config/config.yml'))
   env = Environment(loader = FileSystemLoader('./templates'), trim_blocks=True, lstrip_blocks=True)
   template = env.get_template('template')
   #print(template.render(config_data))
   return template.render(config_data)
 
def write_file(string_to_write):
    f = open(DOCKER_FILE_PATH, 'w')
    f.write(string_to_write)
    f.close()
    print("Docker Compose file is placed on "+ DOCKER_FILE_PATH)
 
def call_docker_compose(config_file_path, cmd):
    if cmd == "up":
       cmd = " up -d"
    cmd = "/usr/local/bin/docker-compose -f "+ config_file_path + "-p nord "+ cmd
    p = subprocess.call(cmd,shell=True)
 
def main():
    try:
       CMD = str(sys.argv[1])
    except:
       print("Docker-compose command must not be null")
       print("Usage: python create_vpn.py <up/down/ps>")
       return
    string = str(genarate_config())
    write_file(string)
    call_docker_compose(DOCKER_FILE_PATH, CMD)
 
if __name__ == '__main__':
   main()
